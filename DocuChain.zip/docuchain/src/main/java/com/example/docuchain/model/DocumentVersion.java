package com.example.docuchain.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class DocumentVersion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int versionNumber;

    @Lob
    private String content;

    private Instant createdAt = Instant.now();

    private String contentHash;

    @ManyToOne(fetch = FetchType.LAZY)
    private Document document;

    public DocumentVersion() {}

    public DocumentVersion(int versionNumber, String content, String contentHash) {
        this.versionNumber = versionNumber;
        this.content = content;
        this.contentHash = contentHash;
    }

    public Long getId() { return id; }
    public int getVersionNumber() { return versionNumber; }
    public void setVersionNumber(int versionNumber) { this.versionNumber = versionNumber; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public String getContentHash() { return contentHash; }
    public void setContentHash(String contentHash) { this.contentHash = contentHash; }
    public Document getDocument() { return document; }
    public void setDocument(Document document) { this.document = document; }
}
