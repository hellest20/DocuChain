package com.example.docuchain.service;

import com.example.docuchain.model.Document;
import com.example.docuchain.model.DocumentVersion;
import com.example.docuchain.repo.DocumentRepository;
import com.example.docuchain.repo.DocumentVersionRepository;
import com.example.docuchain.util.HashUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final DocumentVersionRepository versionRepository;
    private final BlockchainService blockchainService;

    public DocumentService(DocumentRepository documentRepository, DocumentVersionRepository versionRepository, BlockchainService blockchainService) {
        this.documentRepository = documentRepository;
        this.versionRepository = versionRepository;
        this.blockchainService = blockchainService;
    }

    public List<Document> findAll() {
        return documentRepository.findAll();
    }

    public Optional<Document> findById(Long id) {
        return documentRepository.findById(id);
    }

    @Transactional
    public Document createOrUpdate(String name, String content, Long idIfExisting) {
        Document doc = idIfExisting == null ? new Document(name) :
                documentRepository.findById(idIfExisting).orElseThrow(() -> new IllegalArgumentException("Document not found"));
        if (idIfExisting == null) {
            documentRepository.save(doc);
        } else if (name != null && !name.isBlank()) {
            doc.setName(name);
        }

        int nextVersion = versionRepository.countByDocumentId(doc.getId()) + 1;
        String payloadHash = HashUtil.sha256(content);
        DocumentVersion v = new DocumentVersion(nextVersion, content, payloadHash);
        doc.addVersion(v);
        documentRepository.save(doc);

        blockchainService.appendBlock(doc.getId(), nextVersion, payloadHash);
        return doc;
    }

    public List<DocumentVersion> getVersions(Long documentId) {
        return versionRepository.findByDocumentIdOrderByVersionNumberAsc(documentId);
    }
}
