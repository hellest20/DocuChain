package com.example.docuchain.controller;

import com.example.docuchain.model.Document;
import com.example.docuchain.model.DocumentVersion;
import com.example.docuchain.service.DocumentService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @GetMapping
    public List<Document> all() {
        return documentService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> get(@PathVariable Long id) {
        return documentService.findById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/versions")
    public List<DocumentVersion> versions(@PathVariable Long id) {
        return documentService.getVersions(id);
    }

    public record CreateReq(@NotBlank String name, @NotBlank String content) {}
    @PostMapping
    public Document create(@RequestBody CreateReq req) {
        return documentService.createOrUpdate(req.name(), req.content(), null);
    }

    public record UpdateReq(String name, @NotBlank String content) {}
    @PostMapping("/{id}/versions")
    public Document update(@PathVariable Long id, @RequestBody UpdateReq req) {
        return documentService.createOrUpdate(req.name(), req.content(), id);
    }
}
