package com.example.docuchain.controller;

import com.example.docuchain.service.BlockchainService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/blockchain")
public class BlockchainController {

    private final BlockchainService blockchainService;

    public BlockchainController(BlockchainService blockchainService) {
        this.blockchainService = blockchainService;
    }

    @GetMapping("/validate")
    public Map<String, Object> validate() {
        boolean ok = blockchainService.validateChain();
        return Map.of("valid", ok);
    }
}
