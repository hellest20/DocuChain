package com.example.docuchain.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class Block {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private long indexNumber;
    private Instant timestamp;
    private Long documentId;
    private int versionNumber;
    private String previousHash;
    private String payloadHash; // hash of document version content
    private String hash;

    public Block() {}

    public Block(long indexNumber, Instant timestamp, Long documentId, int versionNumber, String previousHash, String payloadHash, String hash) {
        this.indexNumber = indexNumber;
        this.timestamp = timestamp;
        this.documentId = documentId;
        this.versionNumber = versionNumber;
        this.previousHash = previousHash;
        this.payloadHash = payloadHash;
        this.hash = hash;
    }

    public Long getId() { return id; }
    public long getIndexNumber() { return indexNumber; }
    public void setIndexNumber(long indexNumber) { this.indexNumber = indexNumber; }
    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }
    public Long getDocumentId() { return documentId; }
    public void setDocumentId(Long documentId) { this.documentId = documentId; }
    public int getVersionNumber() { return versionNumber; }
    public void setVersionNumber(int versionNumber) { this.versionNumber = versionNumber; }
    public String getPreviousHash() { return previousHash; }
    public void setPreviousHash(String previousHash) { this.previousHash = previousHash; }
    public String getPayloadHash() { return payloadHash; }
    public void setPayloadHash(String payloadHash) { this.payloadHash = payloadHash; }
    public String getHash() { return hash; }
    public void setHash(String hash) { this.hash = hash; }
}
