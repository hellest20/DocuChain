package com.example.docuchain.service;

import com.example.docuchain.model.Block;
import com.example.docuchain.repo.BlockRepository;
import com.example.docuchain.util.HashUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class BlockchainService {

    private final BlockRepository blockRepository;

    public BlockchainService(BlockRepository blockRepository) {
        this.blockRepository = blockRepository;
        ensureGenesis();
    }

    @Transactional
    public void ensureGenesis() {
        if (blockRepository.count() == 0) {
            String payloadHash = HashUtil.sha256("GENESIS");
            String hash = computeHash(0, Instant.EPOCH, -1L, 0, "0", payloadHash);
            Block genesis = new Block(0, Instant.EPOCH, -1L, 0, "0", payloadHash, hash);
            blockRepository.save(genesis);
        }
    }

    public Block getLastBlock() {
        Block last = blockRepository.findTopByOrderByIndexNumberDesc();
        if (last == null) ensureGenesis();
        return blockRepository.findTopByOrderByIndexNumberDesc();
    }

    @Transactional
    public Block appendBlock(Long documentId, int versionNumber, String payloadHash) {
        Block last = getLastBlock();
        long nextIndex = last.getIndexNumber() + 1;
        Instant now = Instant.now();
        String hash = computeHash(nextIndex, now, documentId, versionNumber, last.getHash(), payloadHash);
        Block block = new Block(nextIndex, now, documentId, versionNumber, last.getHash(), payloadHash, hash);
        return blockRepository.save(block);
    }

    public boolean validateChain() {
        List<Block> blocks = blockRepository.findAll().stream()
                .sorted((a,b) -> Long.compare(a.getIndexNumber(), b.getIndexNumber()))
                .toList();
        String prevHash = "0";
        for (Block b : blocks) {
            String computed = computeHash(b.getIndexNumber(), b.getTimestamp(), b.getDocumentId(), b.getVersionNumber(), prevHash, b.getPayloadHash());
            if (!computed.equals(b.getHash())) return false;
            prevHash = b.getHash();
        }
        return true;
    }

    private String computeHash(long index, Instant ts, Long docId, int ver, String prevHash, String payloadHash) {
        String data = index + "|" + ts.toString() + "|" + docId + "|" + ver + "|" + prevHash + "|" + payloadHash;
        return HashUtil.sha256(data);
    }
}
