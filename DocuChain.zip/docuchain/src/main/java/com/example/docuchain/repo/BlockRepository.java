package com.example.docuchain.repo;

import com.example.docuchain.model.Block;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BlockRepository extends JpaRepository<Block, Long> {
    Block findTopByOrderByIndexNumberDesc();
}
