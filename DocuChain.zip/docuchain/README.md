# 📑 DocuChain – Blockchain Document Management

Ein **Blockchain-basiertes Dokumenten-Management-System**, das Dokumente revisionssicher speichert und versioniert.

## 🚀 Schnellstart (lokal, ohne externe Abhängigkeiten)
Voraussetzungen: Java 21, Maven

```bash
mvn spring-boot:run
```

H2 Console: http://localhost:8080/h2-console (JDBC: `jdbc:h2:mem:docuchain`, User: `sa`)

## 🛠️ API-Endpoints
- `GET /api/documents` → alle Dokumente
- `POST /api/documents` → neues Dokument anlegen  
  Body:
  ```json
  { "name":"Vertrag A", "content":"Erste Version des Vertrags" }
  ```
- `GET /api/documents/{id}` → Dokument + Versionen (lazy)
- `GET /api/documents/{id}/versions` → alle Versionen
- `POST /api/documents/{id}/versions` → neue Version hinzufügen  
  Body:
  ```json
  { "name":"optional-neuer-name", "content":"Überarbeiteter Inhalt" }
  ```
- `GET /api/blockchain/validate` → `{ "valid": true|false }`

## 🧱 Wie funktioniert die Blockchain hier?
Jede neue Dokumentversion erzeugt einen **Block** mit:
- `indexNumber`, `timestamp`, `documentId`, `versionNumber`
- `payloadHash` = SHA-256 des Inhalts
- `previousHash` = Hash des vorherigen Blocks
- `hash` = SHA-256 über alle Felder → schützt vor Manipulation

Ein **Genesis-Block** wird automatisch beim Start erzeugt.

## 🧩 Architektur
- **Spring Boot 3**, **Spring Web**, **Spring Data JPA**
- **H2 In-Memory DB** (Profile für Postgres leicht nachrüstbar)
- Schichten: Controller → Service → Repository → JPA-Entities
- `BlockchainService` verwaltet die Chain & Validierung

## ✅ Tests
```bash
mvn test
```

## 📄 Lizenz
MIT
